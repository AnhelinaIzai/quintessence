class EmployeesController < ApplicationController
	before_action :authenticate_user!
  def index
  end
  def new
  end
  def create
  end
  def edit
  end
  def show
  end
  def update
  end
  def destroy
  end
end
