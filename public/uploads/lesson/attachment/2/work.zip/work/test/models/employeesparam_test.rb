require 'test_helper'

class EmployeesparamTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
