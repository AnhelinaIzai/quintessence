﻿using System;


namespace lab4
{
    interface IEquatable<Elipse>
    {
        bool Equals(Elipse line);
    }
    class Point
    {
        public double X;
        public double Y;

        public Point(double x, double y)
        {
            this.X = x;
            this.Y = y;
        }
        public Point()
        {
        }
    }
    [Serializable]
    class Elipse : IEquatable<Elipse>, ICloneable
    {
        const double Pi = Math.PI;
        public double A;
        public double B;
        public Point Center;

        public Elipse(double a, double b, Point center)
        {
            A = a;
            B = b;
            Center = center;
        }
        public Elipse()
        {
        }
        public double Eccentricity { get => Math.Sqrt(Math.Abs(Math.Pow(A, 2) - Math.Pow(B, 2))) / A; }
        public object Clone() => new Elipse(A, B, Center);
        public bool Equals(Elipse other)
        {
            return A == other.A && B == other.B && Center == other.Center;
        }
        public double Area()
        {
            return A * B * Pi;
        }
        public static bool operator ==(Elipse e1, Elipse e2) => e1.Area() == e2.Area();
        public static bool operator !=(Elipse e1, Elipse e2) => e1.Area() != e2.Area();
        public static Elipse operator *(Elipse e1, double num)
        {
            e1.A += num;
            e1.B += num;
            return e1;
        }
        public static Elipse operator +(Elipse elipse, Point p)
        {
            elipse.Center.X += p.X;
            elipse.Center.Y += p.Y;
            return elipse;
        }
        static void Main(string[] args)
        {
            Point center = new Point(0, 0);
            Point zsuv = new Point(1, 4);
            Elipse elipse = new Elipse(2, 3, center);
            Console.WriteLine(elipse.Area());
            Elipse elipse1 = new Elipse(3, 2, center);
            Console.WriteLine(elipse1.Area());
            Console.WriteLine(elipse.A.ToString() + " " + elipse.B.ToString());
            elipse *= -2;
            Console.WriteLine(elipse.A.ToString() + " " + elipse.B.ToString());
            Console.WriteLine(elipse == elipse1);
            elipse += zsuv;
            Console.WriteLine(elipse.Center.X + " " + elipse.Center.Y);
            Console.ReadKey();
        }
    }
    [Serializable]
    class SimpleElipse : Elipse
    {
        public SimpleElipse(double a, double b, Point center) : base(a, b, center)
        {
        }
        public SimpleElipse()
        {
        }
        public bool Contains(double a, double b, Point point)
        {
            double result = (Math.Pow(point.X, 2) / Math.Pow(a, 2)) + (Math.Pow(point.Y, 2) / Math.Pow(b, 2));
            if (result <= 1)
            {
                return true;
            }
            else return false;
        }
    }
}
